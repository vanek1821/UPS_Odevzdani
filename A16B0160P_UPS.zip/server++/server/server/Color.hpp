//
//  Color.hpp
//  server
//
//  Created by Jakub  Vaněk on 11/12/2018.
//  Copyright © 2018 Jakub  Vaněk. All rights reserved.
//

#ifndef Color_hpp
#define Color_hpp

#include <stdio.h>

using namespace std;

enum class COLOR{
    BLACK, WHITE
};
#endif /* Color_hpp */
