//
//  Type.hpp
//  server
//
//  Created by Jakub  Vaněk on 11/12/2018.
//  Copyright © 2018 Jakub  Vaněk. All rights reserved.
//

#ifndef Type_hpp
#define Type_hpp

#include <stdio.h>

using namespace std;

enum class TYPE{
  KING, QUEEN, ROOK, KNIGHT, BISHOP, PAWN
};
#endif /* Type_hpp */
