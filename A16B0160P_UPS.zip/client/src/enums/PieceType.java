package enums;

public enum PieceType {
	KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN;
}
