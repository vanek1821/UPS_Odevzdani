package enums;

public enum ClientState {
	START, LOBBY, ROOM, GAME, REPLAY
}
