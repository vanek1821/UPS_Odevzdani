package enums;

public enum Color {
	WHITE, BLACK;
}
